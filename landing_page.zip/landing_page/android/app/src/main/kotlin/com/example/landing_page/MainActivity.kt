package com.example.landing_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
