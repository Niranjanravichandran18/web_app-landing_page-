import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Landing Page',
      home: LandingPage(),
    );
  }
}

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  TextEditingController tagController = TextEditingController();

  void _saveTag(String tag) {
    FirebaseFirestore.instance.collection('seo_tags').add({'tag': tag});
    tagController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Landing Page'),
      ),
      // body: Center(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.center,
      //     children: <Widget>[
      //       Image.network(
      //         'https://via.placeholder.com/150',
      //         width: 150,
      //         height: 150,
      //       ),
            SizedBox(height: 20),
            Text(
              'Welcome to my landing page!',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Container(
              width: 300,
              child: TextField(
                controller: tagController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Add tags for SEO',
                ),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                _saveTag(tagController.text);
              },
              child: Text('Save Tag'),
            ),
          ],
        ),
      ),
    );
  }
}
